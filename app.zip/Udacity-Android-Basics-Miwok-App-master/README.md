Miwok App
===================================

This app displays lists of vocabulary words for the user to learn the Miwok language.
Used in a Udacity course in the Beginning Android Nanodegree.

## Screenshots
<table>
<tr>
<td><img src="Screenshots/Screenshot_2020-06-08-10-28-13-014_com.example.android.miwok.jpg" style="width: 200px;"/></td>
<td><img src="Screenshots/Screenshot_2020-06-08-10-28-15-037_com.example.android.miwok.jpg" style="width: 200px;"/></td>
</tr>
<tr>
<td><img src="Screenshots/Screenshot_2020-06-08-10-28-16-956_com.example.android.miwok.jpg" style="width: 200px;"/></td>
<td><img src="Screenshots/Screenshot_2020-06-08-10-28-18-753_com.example.android.miwok.jpg" style="width: 200px;"/></td>
</tr>
</table>
